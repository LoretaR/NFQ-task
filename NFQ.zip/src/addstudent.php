<?php
if(isset($_POST['submit'])) {
$name = trim($_POST['name']);



include 'C:\MAMP\htdocs\NFQ\src\dbstudent.php';
}
