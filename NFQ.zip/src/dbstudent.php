<?php
require_once 'C:\MAMP\htdocs\NFQ\src\define.php';
    mysqli_query($mysqli, "INSERT INTO students (name) 
    VALUES('$_POST[name]')");