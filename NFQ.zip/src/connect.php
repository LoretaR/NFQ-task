<?php
$servername = "localhost:3307";
$username = "root";
$password = "root";
$dbname = "nfq task";

$conn = new mysqli($servername, $username, $password, $dbname);

if(!$conn)
{
    die("Connection failed: " . mysqli_connect_error());
}

?> 