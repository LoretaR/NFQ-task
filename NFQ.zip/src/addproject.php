
<?php
if(isset($_POST['create'])) {
    $project = trim($_POST['project']);
    $groupnumber = trim($_POST['groupnumber']);
    $studentcount = trim($_POST['studentcount']);
   

include 'C:\MAMP\htdocs\NFQ\src\dbproject.php';
}