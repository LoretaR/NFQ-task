
<?php
 require_once 'C:\MAMP\htdocs\NFQ\src\define.php';

    mysqli_query($mysqli, "INSERT INTO projects (project, numberofgroups, studentpergroup) 
    VALUES('$_POST[project]', '$_POST[groupnumber]', '$_POST[studentcount]')");