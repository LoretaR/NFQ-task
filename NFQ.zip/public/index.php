
<?php
require('C:\MAMP\htdocs\NFQ\src\addproject.php');
?>
<?php
require('C:\MAMP\htdocs\NFQ\src\addstudent.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NFQ Internship task</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div>
    <button class="open-button" onclick="openForm1()">New Project</button>
    </div>
    <div class="form-popup" id="myForm1">
        <form id="addnew" action="../public/index.php" method="post">

            <label for="project">Project</label><br>
            <input type="text" name="project" required><br>
            <label for="groupnumber">Number of groups</label> <br>
            <input type="number" name="groupnumber" required><br>
            <label for="studentcount">Students per group</label><br>
            <input type="number" name="studentcount" required><br>

            <button name="create" type="submit" id="contact-submit"><b>Submit</b></button>
            <button type="button"  onclick="closeForm1()">Close</button>


        </form>
    </div>
<section class="container">
    <?php
    include 'C:\MAMP\htdocs\NFQ\src\connect.php';
    $sql = "SELECT * FROM projects ORDER BY id DESC LIMIT 1";

    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_row()) {
            echo "Project: <b>$row[1]</b> <br>";
            echo "Number of groups: <b>$row[2]</b><br>";
            echo "Students per group: <b>$row[3]</b>";
        }
        $result->free_result();
    }
    ?>
   

    <h2>Students</h2>
    <table class="students">
        <tr>
            <td>Students</td>
            <td>Group</td>
            <td>Action</td>
        </tr>

        <?php
        include 'C:\MAMP\htdocs\NFQ\src\connect.php';
        $sql = mysqli_query($conn, "SELECT * FROM students");
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <tr>
                <td><?php echo $data['name']; ?></td>
                <td> Group # </td>
                <td><a href="..\src\delete.php?id=<?php echo $data['id']; ?>">Delete</a></td>
            </tr>
        <?php
        }
        ?>
    </table>

    </section>
<section class="addstudent">
    <button class="open-button" onclick="openForm()">Add new student</button>
    <div class="form-popup" id="myForm">
        <form id="contact" action="\NFQ\public\index.php" method="post">
            <label for="name">Name</label><br>
            <input type="text" id="name" name="name"><br>

            <button name="submit" type="submit" id="contact-submit"><b>Submit</b></button>
            <button type="button" class="btn cancel" onclick="closeForm()">Close</button>

        </form>
    </div>
    </section>
    <section class="groups container">
        
    <h2>Groups</h2>
    
    <div class="flex-container">
    <?php
    include 'C:\MAMP\htdocs\NFQ\src\connect.php';
    $sql = "SELECT * FROM projects ORDER BY id DESC LIMIT 1";

    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_row()) {

            $rows = $row[3];
            $tabl = $row[2];
            $cols = 1;
            for ($h = 0; $h < $tabl; $h++) {
                echo "<table>";

                for ($i = 0; $i <= $rows; $i++) {

                    echo "<tr>";

                    for ($j = 0; $j < $cols; $j++) {
                        if ($i == 0 && $j == 0) {
                            $h1 = $h + 1;
                            echo "<th> Group # " . $h1 . "</th>";
                        } else {

    ?> <th> <select class="form-control positionTypes">>
                                    <option selected>Assign student </option>
                                    <?php
                                    include "C:\MAMP\htdocs\NFQ\src\connect.php";
                                    $records = mysqli_query($conn, "SELECT id, name From students");

                                    while ($data = mysqli_fetch_array($records)) {
                                        echo "<option value=" . $data['name'] . ">" . $data['name']  . "</option>";
                                    }
                                    ?>
                                </select>
                                <?php mysqli_close($conn);
                                ?>

                            </th> <?php
                                }
                            }

                            echo "</tr>";
                        }

                        echo "</table>";
                    }
                }
            }

                                    ?>
                                    </div>
</section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $("select.positionTypes").change(function() {
            $("select.positionTypes option[value='" + $(this).data('index') + "']").prop('disabled', false);
            $(this).data('index', this.value);
            $("select.positionTypes option[value='" + this.value + "']:not([value=''])").prop('disabled', true);
        });

        function openForm1() {
            document.getElementById("myForm1").style.display = "block";
        }

        function closeForm1() {
            document.getElementById("myForm1").style.display = "none";
        }

        function openForm() {
            document.getElementById("myForm").style.display = "block";
        }

        function closeForm() {
            document.getElementById("myForm").style.display = "none";
        }

        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>

</html>